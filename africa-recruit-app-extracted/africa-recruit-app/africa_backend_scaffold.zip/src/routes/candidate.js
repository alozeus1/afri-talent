
const express = require('express');
const router = express.Router();
const candidateController = require('../controllers/candidateController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/me', authenticate, authorize(['candidate']), candidateController.getProfile);
router.put('/me', authenticate, authorize(['candidate']), candidateController.updateProfile);

module.exports = router;
