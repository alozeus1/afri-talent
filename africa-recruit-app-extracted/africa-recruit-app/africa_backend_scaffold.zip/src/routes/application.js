
const express = require('express');
const router = express.Router({ mergeParams: true });
const applicationController = require('../controllers/applicationController');
const { authenticate, authorize } = require('../middleware/auth');

// Apply to job
router.post('/', authenticate, authorize(['candidate']), applicationController.applyToJob);

module.exports = router;
