
const express = require('express');
const router = express.Router();
const jobController = require('../controllers/jobController');
const { authenticate, authorize } = require('../middleware/auth');

router.post('/', authenticate, authorize(['employer']), jobController.createJob);
router.get('/', jobController.listJobs);
router.get('/:id', jobController.getJob);
// Additional routes: update, close, etc. can be added here

module.exports = router;
