
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const dotenv = require('dotenv');
const db = require('../config/db');
dotenv.config();

async function register(req, res) {
  const { email, password, role } = req.body;
  if (!email || !password || !['candidate','employer'].includes(role)) {
    return res.status(400).json({ success: false, error: 'Invalid input' });
  }
  try {
    const existing = await db.query('SELECT id FROM users WHERE email=$1', [email]);
    if (existing.rows.length) {
      return res.status(409).json({ success: false, error: 'Email already exists' });
    }
    const hashed = await bcrypt.hash(password, 10);
    const result = await db.query(
      'INSERT INTO users (email, password_hash, role) VALUES ($1, $2, $3) RETURNING id, email, role',
      [email, hashed, role]
    );
    const user = result.rows[0];
    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
    return res.status(201).json({ success: true, data: { id: user.id, email: user.email, role: user.role, token } });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

async function login(req, res) {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Invalid input' });
  }
  try {
    const result = await db.query('SELECT id, email, password_hash, role FROM users WHERE email=$1', [email]);
    if (!result.rows.length) {
      return res.status(401).json({ success: false, error: 'Invalid credentials' });
    }
    const user = result.rows[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return res.status(401).json({ success: false, error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
    return res.status(200).json({ success: true, data: { id: user.id, email: user.email, role: user.role, token } });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

async function me(req, res) {
  return res.status(200).json({ success: true, data: { id: req.user.id, email: req.user.email, role: req.user.role } });
}

module.exports = { register, login, me };
