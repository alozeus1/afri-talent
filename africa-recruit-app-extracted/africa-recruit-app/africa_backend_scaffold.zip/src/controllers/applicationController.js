
const db = require('../config/db');

async function applyToJob(req, res) {
  const jobId = req.params.jobId;
  const candidateId = req.user.id;
  const { coverLetter } = req.body;
  try {
    // Check that job exists and active
    const jobRes = await db.query('SELECT id, status FROM jobs WHERE id=$1', [jobId]);
    if (!jobRes.rows.length || jobRes.rows[0].status !== 'active') {
      return res.status(404).json({ success: false, error: 'Job not found or not active' });
    }
    // Get candidate profile id
    const profileRes = await db.query('SELECT id, resume_id FROM candidate_profiles WHERE user_id=$1', [candidateId]);
    if (!profileRes.rows.length || !profileRes.rows[0].resume_id) {
      return res.status(400).json({ success: false, error: 'Complete your profile and upload a resume before applying' });
    }
    const candidateProfileId = profileRes.rows[0].id;
    // Prevent duplicate application
    const exists = await db.query('SELECT id FROM applications WHERE job_id=$1 AND candidate_profile_id=$2', [jobId, candidateProfileId]);
    if (exists.rows.length) {
      return res.status(409).json({ success: false, error: 'You have already applied to this job' });
    }
    const result = await db.query(
      'INSERT INTO applications (job_id, candidate_profile_id, cover_letter) VALUES ($1,$2,$3) RETURNING id, status',
      [jobId, candidateProfileId, coverLetter]
    );
    // TODO: send notification email to employer
    return res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

module.exports = { applyToJob };
