
const db = require('../config/db');

async function getProfile(req, res) {
  const userId = req.user.id;
  try {
    const result = await db.query('SELECT * FROM candidate_profiles WHERE user_id=$1', [userId]);
    return res.status(200).json({ success: true, data: result.rows[0] || null });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

async function updateProfile(req, res) {
  const userId = req.user.id;
  const { fullName, country, summary, skills, experienceYears, education } = req.body;
  try {
    const result = await db.query('SELECT id FROM candidate_profiles WHERE user_id=$1', [userId]);
    if (result.rows.length) {
      // update
      await db.query(
        'UPDATE candidate_profiles SET full_name=$1, country=$2, summary=$3, skills=$4, experience_years=$5, education=$6 WHERE user_id=$7',
        [fullName, country, summary, skills, experienceYears, education, userId]
      );
    } else {
      await db.query(
        'INSERT INTO candidate_profiles (user_id, full_name, country, summary, skills, experience_years, education) VALUES ($1,$2,$3,$4,$5,$6,$7)',
        [userId, fullName, country, summary, skills, experienceYears, education]
      );
    }
    const updated = await db.query('SELECT * FROM candidate_profiles WHERE user_id=$1', [userId]);
    return res.status(200).json({ success: true, data: updated.rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

module.exports = { getProfile, updateProfile };
