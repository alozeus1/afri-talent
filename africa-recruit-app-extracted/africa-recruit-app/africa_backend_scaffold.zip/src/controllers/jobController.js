
const db = require('../config/db');

async function createJob(req, res) {
  const userId = req.user.id;
  const { title, description, requiredSkills, country, eligibleCountries, isRemote, visaSponsorship, relocationAssistance, category, applicationDeadline } = req.body;
  try {
    // find company id
    const companyRes = await db.query('SELECT id FROM companies WHERE user_id=$1', [userId]);
    if (!companyRes.rows.length) {
      return res.status(400).json({ success: false, error: 'Company profile missing' });
    }
    const companyId = companyRes.rows[0].id;
    const result = await db.query(
      'INSERT INTO jobs (company_id, title, description, required_skills, country, eligible_countries, is_remote, visa_sponsorship, relocation_assistance, category, application_deadline) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *',
      [companyId, title, description, requiredSkills, country || null, eligibleCountries || null, isRemote, visaSponsorship, relocationAssistance, category, applicationDeadline]
    );
    return res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

async function listJobs(req, res) {
  const { q, country, remote, visa, relocation, category, page = 1, pageSize = 10 } = req.query;
  const offset = (page - 1) * pageSize;
  let where = "status='active'";
  const params = [];
  let idx = 1;
  if (q) {
    where += ` AND search_vector @@ plainto_tsquery('english', $${idx++})`;
    params.push(q);
  }
  if (country) {
    where += ` AND (country = $${idx} OR (is_remote = true AND ($${idx} = ANY(eligible_countries))))`;
    params.push(country);
    idx++;
  }
  if (remote) {
    where += ` AND is_remote = true`;
  }
  if (visa) {
    where += ` AND visa_sponsorship = true`;
  }
  if (relocation) {
    where += ` AND relocation_assistance = true`;
  }
  if (category) {
    where += ` AND category = $${idx}`;
    params.push(category);
    idx++;
  }
  try {
    const listRes = await db.query(
      `SELECT * FROM jobs WHERE ${where} ORDER BY posted_at DESC LIMIT $${idx} OFFSET $${idx+1}`,
      params.concat([pageSize, offset])
    );
    const countRes = await db.query(`SELECT COUNT(*) FROM jobs WHERE ${where}`, params);
    return res.status(200).json({ success: true, data: { items: listRes.rows, page: parseInt(page), pageSize: parseInt(pageSize), total: parseInt(countRes.rows[0].count) } });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

async function getJob(req, res) {
  const jobId = req.params.id;
  try {
    const result = await db.query('SELECT * FROM jobs WHERE id=$1', [jobId]);
    if (!result.rows.length) return res.status(404).json({ success: false, error: 'Job not found' });
    const job = result.rows[0];
    // if job is pending or closed, ensure user is employer or admin or company owner
    if (job.status !== 'active') {
      if (!req.user) {
        return res.status(404).json({ success: false, error: 'Job not found' });
      }
      // allow admin or company owner
      if (req.user.role === 'admin') {
        // ok
      } else {
        // check company
        const companyRes = await db.query('SELECT id FROM companies WHERE user_id=$1', [req.user.id]);
        if (!companyRes.rows.length || companyRes.rows[0].id !== job.company_id) {
          return res.status(404).json({ success: false, error: 'Job not found' });
        }
      }
    }
    return res.status(200).json({ success: true, data: job });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, error: 'Internal server error' });
  }
}

module.exports = { createJob, listJobs, getJob };
