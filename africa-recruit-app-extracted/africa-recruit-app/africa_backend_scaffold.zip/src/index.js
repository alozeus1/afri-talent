
const express = require('express');
const app = express();
const dotenv = require('dotenv');
dotenv.config();

const authRoutes = require('./routes/auth');
const candidateRoutes = require('./routes/candidate');
const jobRoutes = require('./routes/job');
const applicationRoutes = require('./routes/application');

app.use(express.json());

// Routes
app.use('/auth', authRoutes);
app.use('/candidates', candidateRoutes);
app.use('/jobs', (req, res, next) => {
  if (req.method === 'POST') {
    // The employer job creation is handled in jobRoutes
    return jobRoutes(req, res, next);
  }
  next();
});
app.use('/jobs', jobRoutes);
// Nested route for applications: /jobs/:jobId/applications
app.use('/jobs/:jobId/applications', applicationRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
